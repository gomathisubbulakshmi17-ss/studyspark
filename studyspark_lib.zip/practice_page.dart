import 'package:flutter/material.dart';

class PracticePage extends StatefulWidget {
  final String subject;
  final String chapter;

  const PracticePage({
    super.key,
    required this.subject,
    required this.chapter,
  });

  @override
  State<PracticePage> createState() => _PracticePageState();
}

class _PracticePageState extends State<PracticePage> {
  int? selectedAnswer;
  bool showAnswer = false;

  final List<Map<String, dynamic>> questions = [
    {
      'question': 'What is the main purpose of a database?',
      'options': [
        'To store and organize data',
        'To print documents',
        'To display pictures only',
        'To control the keyboard',
      ],
      'answer': 0,
      'explanation':
          'A database stores and organizes data so it can be accessed and managed.',
    },
    {
      'question': 'Which of these is a programming language?',
      'options': ['HTML', 'Python', 'CSS', 'HTTP'],
      'answer': 1,
      'explanation':
          'Python is a programming language used for many tasks, including AI and data analysis.',
    },
    {
      'question': 'What does CPU stand for?',
      'options': [
        'Computer Processing Utility',
        'Central Program Unit',
        'Central Processing Unit',
        'Computer Power Unit',
      ],
      'answer': 2,
      'explanation':
          'CPU stands for Central Processing Unit. It executes instructions in a computer.',
    },
  ];

  @override
  Widget build(BuildContext context) {
    final question = questions[0];
    final options = question['options'] as List<String>;
    final correctAnswer = question['answer'] as int;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Practice Questions'),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            widget.subject,
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            widget.chapter,
            style: const TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 20),
          const Text(
            'Question 1',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            question['question'] as String,
            style: const TextStyle(fontSize: 18),
          ),
          const SizedBox(height: 12),
          ...List.generate(options.length, (index) {
            return Card(
              child: RadioListTile<int>(
                title: Text(options[index]),
                value: index,
                groupValue: selectedAnswer,
                onChanged: showAnswer
                    ? null
                    : (value) {
                        setState(() {
                          selectedAnswer = value;
                        });
                      },
              ),
            );
          }),
          const SizedBox(height: 12),
          ElevatedButton(
            onPressed: selectedAnswer == null || showAnswer
                ? null
                : () {
                    setState(() {
                      showAnswer = true;
                    });
                  },
            child: const Text('Check Answer'),
          ),
          if (showAnswer) ...[
            const SizedBox(height: 12),
            Text(
              selectedAnswer == correctAnswer
                  ? 'Correct answer!'
                  : 'Not quite. The correct answer is ${options[correctAnswer]}.',
              style: TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.bold,
                color: selectedAnswer == correctAnswer
                    ? Colors.green
                    : Colors.red,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Explanation',
              style: TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(question['explanation'] as String),
          ],
        ],
      ),
    );
  }
}