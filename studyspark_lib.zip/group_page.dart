import 'package:flutter/material.dart';
import 'download_page.dart';

class GroupPage extends StatelessWidget {
  final String selectedClass;

  const GroupPage({
    super.key,
    required this.selectedClass,
  });

  final groups = const [
    "Bio-Maths",
    "Computer Science",
    "Commerce",
    "Pure Science",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Choose Group - $selectedClass"),
      ),
      body: ListView.builder(
        itemCount: groups.length,
        itemBuilder: (context, index) {
          return Card(
            margin: const EdgeInsets.all(10),
            child: ListTile(
              leading: const Icon(
                Icons.school,
                color: Colors.blue,
              ),
              title: Text(
                groups[index],
                style: const TextStyle(
                  fontSize: 18,
                ),
              ),
              subtitle: const Text("Select this group"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => GroupSubjectPage(
                      selectedClass: selectedClass,
                      selectedGroup: groups[index],
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

class GroupSubjectPage extends StatelessWidget {
  final String selectedClass;
  final String selectedGroup;

  const GroupSubjectPage({
    super.key,
    required this.selectedClass,
    required this.selectedGroup,
  });

  @override
  Widget build(BuildContext context) {
    late final List<String> subjects;

    if (selectedGroup == "Bio-Maths") {
      subjects = [
        "Tamil",
        "English",
        "Mathematics",
        "Physics",
        "Chemistry",
        "Biology",
      ];
    } else if (selectedGroup == "Computer Science") {
      subjects = [
        "Tamil",
        "English",
        "Mathematics",
        "Physics",
        "Chemistry",
        "Computer Science",
      ];
    } else if (selectedGroup == "Commerce") {
      subjects = [
        "Tamil",
        "English",
        "Accountancy",
        "Commerce",
        "Economics",
        "Business Mathematics",
      ];
    } else if (selectedGroup == "Pure Science") {
      subjects = [
        "English",
        "Tamil",
        "Physics",
        "Chemistry",
        "Botany",
        "Zoology",
      ];
    } else {
      subjects = [];
    }

    return Scaffold(
      appBar: AppBar(
        title: Text("$selectedGroup Subjects"),
      ),
      body: ListView.builder(
        itemCount: subjects.length,
        itemBuilder: (context, index) {
          return Card(
            margin: const EdgeInsets.all(10),
            child: ListTile(
              leading: const Icon(
                Icons.menu_book,
                color: Colors.blue,
              ),
              title: Text(
                subjects[index],
                style: const TextStyle(
                  fontSize: 18,
                ),
              ),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => DownloadPage(
                      subject: subjects[index],
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}