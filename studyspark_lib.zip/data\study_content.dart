class StudyContent {
  static const Map<String, List<String>> chapters = {
    'Botany': [
      'Introduction to Botany',
      'Plant Cell Structure',
      'Plant Tissues',
    ],
    'Zoology': [
      'Introduction to Zoology',
      'Animal Cell Structure',
      'Animal Tissues',
    ],
    'Physics': [
      'Introduction to Physics',
      'Motion',
      'Laws of Motion',
    ],
    'Chemistry': [
      'Introduction to Chemistry',
      'Atomic Structure',
      'Chemical Bonding',
    ],
    'Mathematics': [
      'Sets',
      'Relations and Functions',
      'Basic Algebra',
    ],
    'Computer Science': [
      'Introduction to Computers',
      'Computer Organization',
      'Programming Fundamentals',
    ],
    'Commerce': [
      'Introduction to Commerce',
      'Business Activities',
      'Forms of Business Organisation',
    ],
    'Accountancy': [
      'Introduction to Accounting',
      'Basic Accounting Concepts',
      'Journal and Ledger',
    ],
    'Economics': [
      'Introduction to Economics',
      'Basic Economic Concepts',
      'Demand and Supply',
    ],
    'English': [
      'Prose',
      'Poetry',
      'Grammar',
    ],
    'Tamil': [
      'பாடம் 1',
      'பாடம் 2',
      'பாடம் 3',
    ],
  };

  static List<String> getChapters(String subject) {
    return chapters[subject] ?? [];
  }

  static const Map<String, Map<String, String>> notes = {
    'Physics': {
      'Introduction to Physics':
          'Physics is the branch of science that studies matter, energy, motion, and their interactions.\n\n'
          'Important Points:\n'
          '• Physics helps us understand natural phenomena.\n'
          '• Measurements are important in scientific experiments.\n'
          '• Physical quantities can be expressed using units.',
      'Motion':
          'Motion is the change in the position of an object with time relative to a reference point.\n\n'
          'Important Points:\n'
          '• Distance is the total path travelled.\n'
          '• Displacement is the change in position.\n'
          '• Speed is distance travelled per unit time.\n'
          '• SI unit of speed is metre per second (m/s).',
      'Laws of Motion':
          'Newton’s laws describe the relationship between an object’s motion and the forces acting on it.\n\n'
          'Important Points:\n'
          '• The first law describes inertia.\n'
          '• The second law relates force, mass, and acceleration.\n'
          '• The third law states that interaction forces occur in equal and opposite pairs.',
    },
    'Botany': {
      'Introduction to Botany':
          'Botany is the branch of biology concerned with the study of plants.\n\n'
          'Important Points:\n'
          '• Plants are living organisms.\n'
          '• Plants vary in structure and habitat.\n'
          '• Plant science contributes to agriculture and environmental studies.',
      'Plant Cell Structure':
          'Plant cells are the basic structural units of plants.\n\n'
          'Important Points:\n'
          '• The cell membrane surrounds the cell contents.\n'
          '• The cell wall provides support.\n'
          '• The nucleus contains genetic material.\n'
          '• Chloroplasts are associated with photosynthesis.',
      'Plant Tissues':
          'Plant tissues are groups of cells that perform particular functions.\n\n'
          'Important Points:\n'
          '• Meristematic tissues are associated with growth.\n'
          '• Permanent tissues perform specialized functions.\n'
          '• Xylem transports water and minerals.\n'
          '• Phloem transports sugars.',
    },
    'Zoology': {
      'Introduction to Zoology':
          'Zoology is the branch of biology that studies animals.\n\n'
          'Important Points:\n'
          '• Animals show a wide range of structures and adaptations.\n'
          '• Animals obtain energy from food.\n'
          '• Zoology helps us understand animal diversity.',
      'Animal Cell Structure':
          'An animal cell is a basic structural and functional unit of an animal.\n\n'
          'Important Points:\n'
          '• The cell membrane encloses the cell.\n'
          '• The nucleus contains genetic material.\n'
          '• Mitochondria help release usable energy from food.',
      'Animal Tissues':
          'Animal tissues are groups of similar cells that perform specific functions.\n\n'
          'Important Points:\n'
          '• Epithelial tissue covers surfaces.\n'
          '• Connective tissue supports and connects structures.\n'
          '• Muscle tissue produces movement.\n'
          '• Nervous tissue transmits signals.',
    },
  };

  static String getNotes(String subject, String chapter) {
    return notes[subject]?[chapter] ??
        'Notes for this chapter have not been added yet.';
  }
}