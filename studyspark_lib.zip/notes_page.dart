import 'package:flutter/material.dart';
import 'data/study_content.dart';
import 'practice_questions_page.dart';

class NotesPage extends StatelessWidget {
  final String subject;
  final String chapter;

  const NotesPage({
    super.key,
    required this.subject,
    required this.chapter,
  });

  @override
  Widget build(BuildContext context) {
    final notes = StudyContent.getNotes(subject, chapter);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Study Notes'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              subject,
              style: const TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              chapter,
              style: const TextStyle(
                fontSize: 20,
                color: Colors.blue,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 25),
            const Text(
              '📖 Chapter Notes',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              notes,
              style: const TextStyle(
                fontSize: 17,
                height: 1.7,
              ),
            ),
            const SizedBox(height: 30),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.quiz),
                label: const Text(
                  'Practice Questions',
                  style: TextStyle(fontSize: 17),
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => PracticeQuestionsPage(
                        subject: subject,
                        chapter: chapter,
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}