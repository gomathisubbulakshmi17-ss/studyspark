import 'package:flutter/material.dart';
import 'data/syllabus_data.dart';
import 'group_page.dart';
import 'chapter_page.dart';

void main() {
  runApp(const StudySpark());
}

class StudySpark extends StatelessWidget {
  const StudySpark({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'StudySpark',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
      ),
      home: const WelcomePage(),
    );
  }
}

// --------------------------------------------------
// WELCOME PAGE
// --------------------------------------------------

class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.school,
                size: 100,
                color: Colors.blue,
              ),
              const SizedBox(height: 20),
              const Text(
                'StudySpark',
                style: TextStyle(
                  fontSize: 35,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                'AI Powered Offline Learning',
                style: TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 20),
              const Text(
                'Tamil Nadu State Board\nClasses 6–12',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.grey,
                ),
              ),
              const SizedBox(height: 40),
              SizedBox(
                width: 220,
                height: 50,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const LanguagePage(),
                      ),
                    );
                  },
                  child: const Text(
                    'Get Started',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// --------------------------------------------------
// LANGUAGE PAGE
// --------------------------------------------------

class LanguagePage extends StatelessWidget {
  const LanguagePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Choose Language'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 220,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const LoginPage(),
                    ),
                  );
                },
                child: const Text('தமிழ்'),
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: 220,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const LoginPage(),
                    ),
                  );
                },
                child: const Text('English'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// --------------------------------------------------
// LOGIN PAGE
// --------------------------------------------------

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Student Login'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              decoration: const InputDecoration(
                labelText: 'Student Name',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const PreferencePage(),
                  ),
                );
              },
              child: const Text('Login'),
            ),
          ],
        ),
      ),
    );
  }
}

// --------------------------------------------------
// STUDY PREFERENCE PAGE
// --------------------------------------------------

class PreferencePage extends StatelessWidget {
  const PreferencePage({super.key});

  static const List<String> preferences = [
    '📖 Reading Notes',
    '🎥 Watching Videos',
    '📝 Practice Questions',
    '🧠 Mixed Learning',
    '⚡ Quick Revision',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Study Preference'),
      ),
      body: ListView.builder(
        itemCount: preferences.length,
        itemBuilder: (context, index) {
          return Card(
            child: ListTile(
              title: Text(
                preferences[index],
                style: const TextStyle(fontSize: 18),
              ),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const ClassPage(),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

// --------------------------------------------------
// CLASS SELECTION PAGE
// --------------------------------------------------

class ClassPage extends StatelessWidget {
  const ClassPage({super.key});

  @override
  Widget build(BuildContext context) {
    final classes = SyllabusData.classes;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Choose Class'),
      ),
      body: ListView.builder(
        itemCount: classes.length,
        itemBuilder: (context, index) {
          final selectedClass = classes[index];

          return Card(
            margin: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 6,
            ),
            child: ListTile(
              leading: const Icon(
                Icons.menu_book,
                color: Colors.blue,
              ),
              title: Text(selectedClass),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: () {
                if (selectedClass == 'Class 11' ||
                    selectedClass == 'Class 12') {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => GroupPage(
                        selectedClass: selectedClass,
                      ),
                    ),
                  );
                } else {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => SubjectPage(
                        selectedClass: selectedClass,
                      ),
                    ),
                  );
                }
              },
            ),
          );
        },
      ),
    );
  }
}

// --------------------------------------------------
// SUBJECT SELECTION PAGE
// --------------------------------------------------

class SubjectPage extends StatelessWidget {
  final String selectedClass;

  const SubjectPage({
    super.key,
    required this.selectedClass,
  });

  @override
  Widget build(BuildContext context) {
    final subjects = SyllabusData.getSubjects(selectedClass);

    return Scaffold(
      appBar: AppBar(
        title: Text('$selectedClass - Choose Subject'),
      ),
      body: subjects.isEmpty
          ? const Center(
              child: Text(
                'Subjects have not been added yet.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16),
              ),
            )
          : ListView.builder(
              itemCount: subjects.length,
              itemBuilder: (context, index) {
                final subject = subjects[index];

                return Card(
                  margin: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 6,
                  ),
                  child: ListTile(
                    leading: const Icon(
                      Icons.book,
                      color: Colors.blue,
                    ),
                    title: Text(subject),
                    trailing: const Icon(Icons.arrow_forward_ios),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ChapterPage(
                            subject: subject,
                          ),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
    );
  }
}