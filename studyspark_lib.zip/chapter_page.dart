import 'package:flutter/material.dart';
import 'data/study_content.dart';
import 'notes_page.dart';

class ChapterPage extends StatelessWidget {
  final String subject;

  const ChapterPage({
    super.key,
    required this.subject,
  });

  @override
  Widget build(BuildContext context) {
    final chapters = StudyContent.getChapters(subject);

    return Scaffold(
      appBar: AppBar(
        title: Text('$subject Chapters'),
      ),
      body: chapters.isEmpty
          ? const Center(
              child: Text(
                'Chapters have not been added yet.',
                style: TextStyle(fontSize: 18),
              ),
            )
          : ListView.builder(
              itemCount: chapters.length,
              itemBuilder: (context, index) {
                final chapter = chapters[index];

                return Card(
                  margin: const EdgeInsets.all(10),
                  child: ListTile(
                    leading: const Icon(
                      Icons.menu_book,
                      color: Colors.blue,
                    ),
                    title: Text(
                      chapter,
                      style: const TextStyle(fontSize: 18),
                    ),
                    trailing: const Icon(
                      Icons.arrow_forward_ios,
                      size: 18,
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => NotesPage(
                            subject: subject,
                            chapter: chapter,
                          ),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
    );
  }
}