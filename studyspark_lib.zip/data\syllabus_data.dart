class SyllabusData {
  // All supported classes
  static const List<String> classes = [
    'Class 6',
    'Class 7',
    'Class 8',
    'Class 9',
    'Class 10',
    'Class 11',
    'Class 12',
  ];

  // Supported learning languages
  static const Map<String, String> languages = {
    'English': 'en',
    'தமிழ்': 'ta',
  };

  // Starter subject categories.
  // These are not the complete official syllabus.
  static const Map<String, List<String>> subjects = {
    'Class 6': [
      'Tamil',
      'English',
      'Mathematics',
      'Science',
      'Social Science',
    ],
    'Class 7': [
      'Tamil',
      'English',
      'Mathematics',
      'Science',
      'Social Science',
    ],
    'Class 8': [
      'Tamil',
      'English',
      'Mathematics',
      'Science',
      'Social Science',
    ],
    'Class 9': [
      'Tamil',
      'English',
      'Mathematics',
      'Science',
      'Social Science',
    ],
    'Class 10': [
      'Tamil',
      'English',
      'Mathematics',
      'Science',
      'Social Science',
    ],
    'Class 11': [
      'Tamil',
      'English',
      'Mathematics',
      'Physics',
      'Chemistry',
      'Computer Science',
      'Biology',
      'Commerce',
      'Accountancy',
      'Economics',
    ],
    'Class 12': [
      'Tamil',
      'English',
      'Mathematics',
      'Physics',
      'Chemistry',
      'Computer Science',
      'Biology',
      'Commerce',
      'Accountancy',
      'Economics',
    ],
  };

  // Get subjects for a selected class
  static List<String> getSubjects(String selectedClass) {
    return subjects[selectedClass] ?? [];
  }

  // Chapter data will be added after verifying the textbooks.
  static List<String> getChapters(
    String selectedClass,
    String subject,
    String language,
  ) {
    return [];
  }
}