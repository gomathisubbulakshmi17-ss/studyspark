import 'package:flutter/material.dart';
import 'chapter_page.dart';
import 'practice_questions_page.dart';
import 'practice_page.dart';

class StudyDashboard extends StatelessWidget {
  final String subject;

  const StudyDashboard({super.key, required this.subject});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(subject)),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Icon(
              Icons.school,
              size: 80,
              color: Colors.blue,
            ),
            const SizedBox(height: 20),

            Text(
              '$subject Study Dashboard',
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 30),

            // Read Notes
            _menuButton(context, '📖 Read Notes', () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ChapterPage(subject: subject),
                ),
              );
            }),

            // Watch Videos
            _menuButton(context, '🎥 Watch Videos', () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => LearningResourcesPage(
                    subject: subject,
                    title: 'Video Lessons',
                    icon: Icons.play_circle_fill,
                  ),
                ),
              );
            }),

            // Practice Questions
            _menuButton(context, '📝 Practice Questions', () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => PracticePage(
                    subject: subject,
                    chapter: 'General Practice',
                  ),
                ),
              );
            }),

            // Previous Year Papers
            _menuButton(context, '📄 Previous Year Papers', () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => LearningResourcesPage(
                    subject: subject,
                    title: 'Previous Year Papers',
                    icon: Icons.description,
                  ),
                ),
              );
            }),

            // Take Quiz
            _menuButton(context, '🧠 Take Quiz', () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => PracticeQuestionsPage(
                    subject: subject,
                    chapter: 'General Quiz',
                  ),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _menuButton(
    BuildContext context,
    String title,
    VoidCallback onPressed,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: SizedBox(
        width: double.infinity,
        child: ElevatedButton(
          onPressed: onPressed,
          child: Text(title),
        ),
      ),
    );
  }
}

class LearningResourcesPage extends StatelessWidget {
  final String subject;
  final String title;
  final IconData icon;

  const LearningResourcesPage({
    super.key,
    required this.subject,
    required this.title,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                size: 80,
                color: Colors.blue,
              ),
              const SizedBox(height: 20),

              Text(
                subject,
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 12),

              Text(
                title,
                style: const TextStyle(fontSize: 20),
              ),

              const SizedBox(height: 20),

              const Text(
                'Learning resources will appear here when they are added to the app.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16),
              ),
            ],
          ),
        ),
      ),
    );
  }
}