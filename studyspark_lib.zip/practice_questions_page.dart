import 'package:flutter/material.dart';

class PracticeQuestionsPage extends StatefulWidget {
  final String subject;
  final String chapter;

  const PracticeQuestionsPage({
    super.key,
    required this.subject,
    required this.chapter,
  });

  @override
  State<PracticeQuestionsPage> createState() =>
      _PracticeQuestionsPageState();
}

class _PracticeQuestionsPageState
    extends State<PracticeQuestionsPage> {
  int currentQuestion = 0;
  int score = 0;
  int? selectedAnswer;
  bool answerChecked = false;
  bool quizFinished = false;

  final List<Map<String, dynamic>> questions = [
    {
      'question': 'Which of the following is used to store data?',
      'options': ['Keyboard', 'Database', 'Monitor', 'Mouse'],
      'answer': 1,
    },
    {
      'question': 'Which language is commonly used for AI programming?',
      'options': ['Python', 'HTML', 'CSS', 'XML'],
      'answer': 0,
    },
    {
      'question': 'What does CPU stand for?',
      'options': [
        'Computer Personal Unit',
        'Central Processing Unit',
        'Control Program Utility',
        'Central Power Unit',
      ],
      'answer': 1,
    },
  ];

  void checkAnswer() {
    if (selectedAnswer == null) return;

    setState(() {
      answerChecked = true;

      if (selectedAnswer == questions[currentQuestion]['answer']) {
        score++;
      }
    });
  }

  void nextQuestion() {
    setState(() {
      if (currentQuestion < questions.length - 1) {
        currentQuestion++;
        selectedAnswer = null;
        answerChecked = false;
      } else {
        quizFinished = true;
      }
    });
  }

  void restartQuiz() {
    setState(() {
      currentQuestion = 0;
      score = 0;
      selectedAnswer = null;
      answerChecked = false;
      quizFinished = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Practice Questions'),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: quizFinished
            ? buildResult()
            : buildQuestion(),
      ),
    );
  }

  Widget buildQuestion() {
    final question = questions[currentQuestion];
    final options = question['options'] as List<String>;
    final correctAnswer = question['answer'] as int;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '${widget.subject} - ${widget.chapter}',
          style: const TextStyle(
            fontSize: 16,
            color: Colors.deepPurple,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 20),
        Text(
          'Question ${currentQuestion + 1} of ${questions.length}',
          style: const TextStyle(fontSize: 16),
        ),
        const SizedBox(height: 12),
        LinearProgressIndicator(
          value: (currentQuestion + 1) / questions.length,
          color: Colors.deepPurple,
        ),
        const SizedBox(height: 24),
        Text(
          question['question'] as String,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 20),
        ...List.generate(options.length, (index) {
          Color? tileColor;

          if (answerChecked && index == correctAnswer) {
            tileColor = Colors.green.shade100;
          } else if (answerChecked && index == selectedAnswer) {
            tileColor = Colors.red.shade100;
          }

          return Card(
            color: tileColor,
            child: RadioListTile<int>(
              title: Text(options[index]),
              value: index,
              groupValue: selectedAnswer,
              activeColor: Colors.deepPurple,
              onChanged: answerChecked
                  ? null
                  : (value) {
                      setState(() {
                        selectedAnswer = value;
                      });
                    },
            ),
          );
        }),
        const SizedBox(height: 16),
        if (answerChecked)
          Text(
            selectedAnswer == correctAnswer
                ? 'Correct answer!'
                : 'Correct answer: ${options[correctAnswer]}',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: selectedAnswer == correctAnswer
                  ? Colors.green
                  : Colors.red,
            ),
          ),
        const Spacer(),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.deepPurple,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.all(15),
            ),
            onPressed: answerChecked
                ? nextQuestion
                : selectedAnswer == null
                    ? null
                    : checkAnswer,
            child: Text(
              answerChecked
                  ? currentQuestion == questions.length - 1
                      ? 'View Results'
                      : 'Next Question'
                  : 'Check Answer',
            ),
          ),
        ),
      ],
    );
  }

  Widget buildResult() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.emoji_events,
            size: 90,
            color: Colors.amber,
          ),
          const SizedBox(height: 20),
          const Text(
            'Quiz Completed!',
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'Your Score: $score / ${questions.length}',
            style: const TextStyle(
              fontSize: 24,
              color: Colors.deepPurple,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'You answered $score questions correctly.',
            style: const TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 30),
          ElevatedButton(
            onPressed: restartQuiz,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.deepPurple,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(
                horizontal: 30,
                vertical: 15,
              ),
            ),
            child: const Text('Try Again'),
          ),
        ],
      ),
    );
  }
}